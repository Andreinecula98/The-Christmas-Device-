EXEC_NAME=leduri
#Input files
INPUT_FILE1="in/t%d/Rezistente.in"
INPUT_FILE2="in/t%d/Leduri.in"
INPUT_FILE3="in/t%d/Cerinte.in"
#Output files
OUT_FILE="out/Rezultate%d.out"

#Reference files
REF_FILE="ref/Rezultate%d.out"

NUMBER_TEST=11
TIMEOUT=5

PUNCTAJ[1]=5
PUNCTAJ[2]=10
PUNCTAJ[3]=20
PUNCTAJ[4]=20
PUNCTAJ[5]=10
PUNCTAJ[6]=12
PUNCTAJ[7]=13
PUNCTAJ[8]=10
PUNCTAJ[9]=10
PUNCTAJ[10]=10
PUNCTAJ[11]=10

DELIM="________________________________________________________"

function show_total {
	echo $DELIM
	echo
	printf "________________________________________________________\n"
	printf "|FINAL GRADE|.................................... %3spt |\n" $1
	printf "|___________|___________________________________________|\n\n"
	echo
}

function run_test {
  nota=0
  for (( i=1; i <= NUMBER_TEST; i++ ))
  do

   passed_test=1
   printf -v file_in1 $INPUT_FILE1 $i 
   printf -v file_in2 $INPUT_FILE2 $i
   printf -v file_in3 $INPUT_FILE3 $i
   printf -v file_out $OUT_FILE $i
   printf -v file_ref $REF_FILE $i

   timeout $TIMEOUT ./$EXEC_NAME $file_in1 $file_in2 $file_in3 $file_out > /dev/null 2>&1 | cat
	 diff  -Z -q $file_out $file_ref > /dev/null 2>&1

   if [ $? -ne 0 ];
   then
     passed_test=0
   fi

	 if [ $i -lt 9 ];
	 then
   	if [ $passed_test -eq 1 ];
   	then
     	printf "Test %2d ................................. OK     ( +"${PUNCTAJ[$i]}"pt)\n" $i
     	nota=$((nota+${PUNCTAJ[$i]}))
   	else
     	printf "Test %2d ................................. BAD    ( +0pt)\n" $i
   	fi
	 else
		 if [ $passed_test -eq 1 ];
    	then
      	printf "Bonus %2d ................................ OK     ( +"${PUNCTAJ[$i]}"pt)\n" $i
      	nota=$((nota+${PUNCTAJ[$i]}))
    	else
      	printf "Bonus %2d ................................ BAD    ( +0pt)\n" $i
    	fi
	 fi
   if [ $i -eq 8 ];
   then
     printf "________________________________________________________\n"
     printf "|                     |BONUS TIME|                     |\n"
     printf "|_____________________|__________|_____________________|\n\n"
	printf "________________________________________________________\n\n"
   fi
 done
	
	if [ $nota -ge 100 ];
	then
		printf "		          \ /								\n"	
		printf "		        -->*<--								\n"
		printf "		          /o\								\n"
		printf "		         /_\_\								\n"
		printf "		        /_/_0_\								\n"
		printf "		       /_o_\_\_\							\n"
		printf "		      /_/_/_/_/o\							\n"
		printf "		     /@\_\_\@\_\_\							\n"
		printf "		    /_/_/O/_/_/_/_\							\n"
		printf "		   /_\_\_\_\_\o\_\_\						\n"
		printf "		  /_/0/_/_/_0_/_/@/_\						\n"
		printf "		 /_\_\_\_\_\_\_\_\_\_\						\n"
		printf "		/_/o/_/_/@/_/_/o/_/0/_\						\n"
		printf "		         [___]  							\n"
	fi
	show_total $nota;

}

rm -rf out/
mkdir out/
make clean
make
echo $DELIM
echo "Executabil = '$EXEC_NAME'"
echo $DELIM
run_test
