#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "structuri.h"
#include "functii.h"
   
void main(int argc, char *argv[])
{
	int N, Y, K, i, j, nr_rez, *cerinte, niv, sol, *used, sol2, *x, ok, stop;
	FILE *f;
	led *vect, *aranjari;
	rezistenta *rez;
	cerinte = (int*)malloc(4 * sizeof(int));

     f = fopen(argv[1], "r");
     if(!f){
    	printf("Eroare");
    	exit(1);
    }

    fscanf(f, "%d", &nr_rez);
    rez = (rezistenta*)malloc(sizeof(rezistenta) * nr_rez);
    scan_rezistente(nr_rez, rez, f);
    fclose(f);

    f = fopen(argv[2], "r");
    if(!f){
    	printf("Eroare");
    	exit(1);
    }

    fscanf(f, "%d%d%d", &N, &Y, &K);
    vect = (led*)malloc(sizeof(led) * N);
    scan_leduri(N, vect, f);
    fclose(f);

    f = fopen(argv[3], "r");
    if(!f){
    	printf("Eroare");
    	exit(1);
    }

    for(i=0;i<4;i++)
    	fscanf(f, "%d", &cerinte[i]);
    fclose(f);

    f=fopen(argv[4], "w");
    if(!f){
        printf("Eroare");
        exit(1);
    }

    if(cerinte[0] == 1)
    	task1(N, vect, f);

     if(cerinte[1] == 1){
       
        x = (int*)calloc(sizeof(int), N);
         for(i=0;i<N;i++)
         	x[i] = vect[i].intensity;
            ok = task2(x,N);
        fprintf(f,"%d\n",ok);
    }
   

    if(cerinte[2] == 1){
    sort_rezistente(nr_rez, rez);
    fprintf(f, "%d\n", task3(vect, rez, N, nr_rez, Y));
}

    if(cerinte[3] == 1){
        aranjari = (led*)malloc(sizeof(led)*N);
        used = (int*)calloc(sizeof(int), N);
        niv = 0;
        sol = 0;
        task4(vect, aranjari, used, N, niv, K, &sol);
        fprintf(f, "%d\n", sol);
        free(aranjari);
        free(used);
    }
    free(vect);
    free(rez);
    free(cerinte);
    fclose(f);  
}
