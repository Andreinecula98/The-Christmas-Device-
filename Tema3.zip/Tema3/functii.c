#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "structuri.h"
#include "functii.h"

// Se citesc ledurile din fiseir
void scan_leduri(int N, led *vect, FILE *f)
{
	int i;
	for(i=0;i<N;i++){
        vect[i].name = (char*)malloc(10*sizeof(char));
        vect[i].color = (char*)malloc(sizeof(char));
    	fscanf(f, "%s%s%d", vect[i].name, vect[i].color, &vect[i].intensity);
    }
}

//Se citesc rezistentele din fisier
void scan_rezistente(int nr_rez, rezistenta *rez, FILE *f)
{
	int i;
   for(i=0;i<nr_rez;i++){
       rez[i].name = (char*)malloc(10*sizeof(char));
       fscanf(f, "%s%d", rez[i].name, &rez[i].value);
    }
}

/*Prima data se parcurge tot vectorul cu leduri
 si se cauta diferenta maxima dintre doua leduri alaturate.
 Apoi se parcurge iar vectorul si se numara cate elemente au 
 diferenta maxima gasita anterior.
*/  
void task1(int N, led *vect, FILE *f)
{
	int i, difmax = 0, nr_led_difmax = 0;
	 for(i=0;i<N-1;i++){
    	if(difmax < abs(vect[i].intensity - vect[i+1].intensity))
    		difmax = abs(vect[i].intensity - vect[i+1].intensity);
    }

    for(i=0;i<N-1;i++){
    	if(difmax == abs(vect[i].intensity - vect[i+1].intensity))
    		nr_led_difmax++;
    }

    fprintf(f,"%d %d\n", difmax, nr_led_difmax);
}

/*Se sorteaza in ordine descrescatoare valorile rezistentelor */
void sort_rezistente(int nr_rez, rezistenta *rez)
{
	int i, j, aux;
	for(i=0;i<nr_rez-1;i++)
	for(j=i+1;j<nr_rez;j++)
		if(rez[i].value < rez[j].value){
            aux = rez[i].value;
            rez[i].value = rez[j].value;
            rez[j].value = aux;
		}
}

/* In variabila rez_update se vor pastra pe rand valorile tuturor
intensitatiilor ledurilor. Se verifica daca rez_update este deja mai mic
decat intensitatea la care trebuie aduse ledurile, caz in se returneaza -1.
Apoi, din rez_update se scade valoarea celei mai mari rezistente aflata 
la dispozitie si se numara rezistentele folosite, atata timp cat rezultatul scaderii este mai mare sau egal cu valoarea Y, la care trebuie aduse intensitatiile.
In cazul in care aceasta rezultatul scaderii ar fi mai mic decat Y, se trece la scaderea urmatoarei rezistente.
*/

int task3 (led *vect, rezistenta *rez, int N, int nr_rez, int Y)
{
	int i, j, used = 0, rez_update;
	for(i=0;i<N;i++){
		rez_update = vect[i].intensity;
		if(rez_update < Y)
			return -1;
		for(j=0; j<nr_rez; j++){
			while(rez_update - rez[j].value >= Y){
				used++;
				rez_update = rez_update - rez[j].value;
			}
		}
	}
	return used;

}

/* In cazul in care am ajuns in punctul in care niv==N inseamna ca am gasit o solutie de aranjare si o numaram.
Altfel, se construieste solutia prin backtracking recursiv.
Daca niv==0 inseamna ca punem primul element in solutie, deci, nu avem cu ce element sa il comparam pentru a vedea daca de respecta conditiile.
Daca niv>0, inseamna ca exista deja cel putin un element in solutie si in momentul in care se se doreste adaugarea altui element se verifica mai intai daca sunt respectate conditiile cerute, si numai in caz afirmativ se apeleaza din nou functia, in mod recursiv
*/
void task4(led *vect, led *aranjari, int *used, int N, int niv, int K, int *sol)
{
     int i;
    if(niv == N)
        (*sol)++;
    else{
       for(i=0;i<N;i++)
         if(used[i] == 0){
           if(niv == 0){
             aranjari[niv] = vect[i];
             used[i] = 1;
             task4(vect, aranjari, used, N, niv+1, K, sol);
             used[i] = 0;
          }

         if(niv > 0)
            if(strcmp(vect[i].color, aranjari[niv-1].color) !=0 && abs(vect[i].intensity - aranjari[niv-1].intensity) <= K){
                aranjari[niv] = vect[i];
                used[i] = 1;
                task4(vect,aranjari,used,N,niv+1,K,sol);
                used[i] = 0;
            }        
         }  
       }
 }

 
 int task2( int *x, int n )
 {
      int *lis, i, j, max = 0;
      lis = (int*)malloc(sizeof(int) * n);
 		for (i=0;i<n;i++) 
 		lis[i] = 1; 
		for (i=1;i<n;i++) 
 		for (j=0;j<i;j++)
 		 if (x[i] < x[j] && lis[i] < lis[j] + 1)
 			lis[i] = lis[j] + 1;
		for (i=0;i<n;i++) 
 		 if (max < lis[i])
 			max = lis[i];
   free(lis);
   return n-max;
}
