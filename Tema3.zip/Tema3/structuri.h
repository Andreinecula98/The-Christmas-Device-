#ifndef _STRUCTURI_H_
#define _STRUCTURI_H_

typedef struct 
{
	char *name;
	char *color;
	int intensity;
}led;

typedef struct
{
	char *name;
	int value;
}rezistenta;

#endif