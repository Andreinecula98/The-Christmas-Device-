#ifndef _FUNCTII_H_
#define _FUNCTII_H_

void scan_leduri(int N, led *vect, FILE *f);
void scan_rezistente(int nr_rez, rezistenta *rez, FILE *f);
void task1(int N, led *vect, FILE *f);
void sort_rezistente(int nr_rez, rezistenta *rez);
int task3 (led *vect, rezistenta *rez, int N, int nr_rez, int Y);
void task4(led *vect, led *aranjari, int *used, int N, int niv, int K, int *sol);
int task2( int *x, int n );

#endif